import pandas as pd

# Load dataset
df = pd.read_csv('/var/www/html/DroneWhisperers/DroneWhisperersApp/static/dataset/nmi_consumption.csv')

# Filter for campus_id 1
df = df[df['campus_id'] == 1]

# Convert timestamp column to datetime
df['timestamp'] = pd.to_datetime(df['timestamp'])

# Drop rows with missing values
df.dropna(subset=['campus_id', 'meter_id', 'timestamp', 'consumption'], inplace=True)

# Filter for year 2021 and 2022
df = df[df['timestamp'].dt.year.isin([2021, 2022])]

# Optional: sort and reset index
df = df.sort_values(by='timestamp').reset_index(drop=True)
df=df[:1000]
# Save to new CSV
output_path = '/var/www/html/DroneWhisperers/DroneWhisperersApp/static/dataset/new_nmi_consumption.csv'
df.to_csv(output_path, index=False)

# Print total number of rows
print("Total rows for 2021 and 2022:", len(df))

