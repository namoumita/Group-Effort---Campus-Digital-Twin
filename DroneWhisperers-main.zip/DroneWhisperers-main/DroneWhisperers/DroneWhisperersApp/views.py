from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect

# Create your views here.
from django.conf import settings
from django.core.mail import send_mail
import pandas as pd
from django.http import JsonResponse
from .models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth import login,logout

from django.contrib.auth.decorators import login_required








def login_view(request):
    if request.method == "POST":
        email = request.POST.get("email", "")
        password = request.POST.get("password", "")
        user=User.objects.get(email=email.lower())
        if user and user.check_password(password):
            login(request,user)
            return redirect('/jenny-grave')
        return render(request,'login.html',{"message":"Invalid email or password."})
            
        

    return render(request,"login.html")

@login_required
def logout_view(request):
    logout(request)
    return redirect('/login')
            
        


def register_view(request):
    if request.method == "POST":
        name = request.POST.get("usrname", "")
        email = request.POST.get("email", "")
        phone = request.POST.get("phone", "")
        password = request.POST.get("password", "")
        hashed_password=make_password(password)
        if email:
            try:
                existing_user_by_email = User.objects.filter(email=email.lower()).exists()
                if existing_user_by_email:
                    return render(request, 'register.html', {"message": "User with Email already exists!"})
            except Exception as e:
                print(f"Error checking email: {e}")
        
        # Check if the mobile number already exists
        if phone:
            try:
                existing_user_by_mobile = User.objects.filter(mobile_no=phone).exists()
                if existing_user_by_mobile:
                    return render(request, 'register.html', {"message": "User with Mobile No. already exists!"})
            except Exception as e:
                print(f"Error checking mobile number: {e}")
        user = User.objects.create(email=email.lower(),name=name,password=hashed_password,mobile_no=phone)
        print('--------user registered in successfully--------')
        # If the credentials are valid, log the user in using Django's built-in login function
        
        return redirect('/login')
        

    return render(request,"register.html")
@login_required(login_url='/login')
def university(request):
    return render(request,'university.html')

def visual_page(request):
    return render(request,'visualization.html')

def water_consumption(request):
    df=pd.read_csv('/var/www/html/DroneWhisperers/DroneWhisperersApp/static/dataset/new_water_consumption.csv')
    df=df[['timestamp', 'consumption']]
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Extract just the date
    df['date'] = df['timestamp'].dt.date

    # Group by date and sum consumption
    daily_total = df.groupby('date')['consumption'].sum().reset_index()
        # Convert to list of dicts (good for JSON)
    chart_data = [
        {"x": row['date'].strftime("%Y-%m-%d"), "y": row['consumption']}
        for _, row in daily_total.iterrows()
    ]

    return JsonResponse(chart_data, safe=False)

def gas_consumption(request):
    df=pd.read_csv('/var/www/html/DroneWhisperers/DroneWhisperersApp/static/dataset/new_gas_consumption.csv')
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    df=df[['timestamp', 'consumption']]
    # Extract just the date
    df['date'] = df['timestamp'].dt.date

    # Group by date and sum consumption
    daily_total = df.groupby('date')['consumption'].sum().reset_index()
        # Convert to list of dicts (good for JSON)
    chart_data = [
        {"x": row['date'].strftime("%Y-%m-%d"), "y": row['consumption']}
        for _, row in daily_total.iterrows()
    ]

    return JsonResponse(chart_data, safe=False)
def electricity_consumption(request):
    try:
        df=pd.read_csv('/var/www/html/DroneWhisperers/DroneWhisperersApp/static/dataset/new_nmi_consumption.csv')
        df['timestamp'] = pd.to_datetime(df['timestamp'])

        df=df[['timestamp', 'consumption']]

        # Extract just the date
        df['date'] = df['timestamp'].dt.date

        # Group by date and sum consumption
        daily_total = df.groupby('date')['consumption'].sum().reset_index()
        # Convert to list of dicts (good for JSON)
        chart_data = [
            {"x": row['date'].strftime("%Y-%m-%d"), "y": row['consumption']}
            for _, row in daily_total.iterrows()
        ]

        return JsonResponse(chart_data, safe=False)
    except Exception as e:
        print(f"{e}-----------------------------")
def contacts(request):
    if request.method == "POST":
        name = request.POST.get("name", "")
        email = request.POST.get("email", "")
        subject = request.POST.get("subject", "")
        message = request.POST.get("message", "")

        email_subject = "New Contact Form Submission – Drone Whisperers"
        email_body = f"""
Dear Admin,

You have received a new contact request from the website.

Details:
Name    : {name}
Email   : {email}
Subject : {subject}
Message : {message}

Please follow up accordingly.

Best regards,
Drone Whisperers Website Bot
"""

        try:
            send_mail(
                email_subject,
                email_body,
                settings.EMAIL_HOST_USER,  # From email
                [settings.EMAIL_HOST_USER],  # To email (admin or your team)
                fail_silently=False,
            )
        except Exception as e:
            print(f"Email sending failed: {e}")

    return redirect("index")

def home_page(request):
    return render(request,'base.html')
def demo(request):
    return render(request,'index.html')
