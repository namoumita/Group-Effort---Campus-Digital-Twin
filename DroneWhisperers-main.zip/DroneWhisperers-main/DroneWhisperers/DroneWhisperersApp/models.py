from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.


class User(AbstractUser):
    mobile_no=models.CharField(max_length=13,blank=True,null=True)
    name=models.CharField(max_length=500)
    username=models.CharField(blank=True,null=True, unique=True,max_length=158)
