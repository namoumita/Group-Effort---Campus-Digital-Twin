from django.apps import AppConfig


class DronewhisperersappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DroneWhisperersApp'
