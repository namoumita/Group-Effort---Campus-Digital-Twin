from django.urls import path
from .views import *
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('',home_page,name="index" ),
    path('demo',demo ),
    path('contact',contacts,name="contact"),
    path('jenny-grave',university,name="university"),
    path('io-data',visual_page,name="data"),
    path('water-consumption',water_consumption,name="water"),
    path('gas-consumption',gas_consumption,name="gas"),
    path('electricity-consumption',electricity_consumption,name="electricity"),
    path('logout',logout_view ,name="logout"),
    path('login',login_view ,name="login"),
    path('register',register_view,name="register" ),
]
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
