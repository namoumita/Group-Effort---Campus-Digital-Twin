import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/controls/OrbitControls.js';
import { DRACOLoader } from 'three/examples/loaders/DRACOLoader.js';

document.addEventListener('DOMContentLoaded', () => {
  const modelPath = '/static/model/final-model.glb';

  const dracoLoader = new DRACOLoader();
  dracoLoader.setDecoderPath("/static/three/examples/jsm/libs/draco/");

  const loader = new GLTFLoader();
  loader.setDRACOLoader(dracoLoader);

  const canvas = document.getElementById('universityCanvas');
  const card = canvas.closest('.university');
  const cardRect = card.getBoundingClientRect();

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setSize(cardRect.width, cardRect.height);
  renderer.setClearColor(0xf8f9fa, 0);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, cardRect.width / cardRect.height, 0.1, 1000);
  camera.position.set(0, 2, 5);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.autoRotate = false;
  controls.enableZoom = true;

  let isMouseOver = false;
  let isVisible = true;
  canvas.addEventListener('mouseenter', () => {
    isMouseOver = true;
    controls.autoRotate = true;
  });
  canvas.addEventListener('mouseleave', () => {
    isMouseOver = false;
    controls.autoRotate = false;
  });
  const visibilityObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.target === canvas) {
        isVisible = entry.isIntersecting;
      }
    });
  }, { threshold: 0.01 });
  visibilityObserver.observe(canvas);

  canvas.addEventListener('webglcontextlost', (event) => {
    event.preventDefault();
    console.warn(`WebGL context lost`);
  });

  canvas.addEventListener('webglcontextrestored', () => {
    console.log(`WebGL context restored`);
    setTimeout(() => location.reload(), 100);
  });

  loader.load(modelPath, (gltf) => {
    const model = gltf.scene;
    model.traverse((child) => {
      if (child.isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;
        child.material.side = THREE.DoubleSide;
      }
    });

    model.scale.set(1, 1, 1);
    model.position.set(0, 0, 0);
    scene.add(model);
    model.rotation.y = Math.PI / 12;  // Rotate 90° clockwise
    model.rotation.x = -Math.PI / 14; // ≈15° tilt, adjust as needed
    model.rotation.z = 0;              // No rotation around forward axis (Z)
    
    // Calculate bounding box and adjust camera
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    const fov = camera.fov * (Math.PI / 180);
    const cameraZ = Math.abs(maxDim / 2 / Math.tan(fov / 2)) * 0.9;

    camera.position.set(center.x + maxDim, center.y + maxDim * 0.5, center.z + maxDim );

    camera.lookAt(center);
    camera.near = 0.1;
    camera.far = cameraZ * 4;
    camera.updateProjectionMatrix();

    controls.target.copy(center);
    controls.update();

    // Lighting
    scene.add(new THREE.AmbientLight(0xffffff, 1));
    const spotLight = new THREE.SpotLight(0xffffff, 1);
    spotLight.position.set(50, 50, 50);
    spotLight.castShadow = true;
    spotLight.shadow.mapSize.width = 2048;
    spotLight.shadow.mapSize.height = 2048;
    spotLight.shadow.bias = -0.001;
    spotLight.shadow.camera.near = 10;
    spotLight.shadow.camera.far = 200;
    spotLight.shadow.camera.fov = 30;
    scene.add(spotLight);

    // Shadow-receiving ground plane
    const planeGeometry = new THREE.PlaneGeometry(100, 100);
    const planeMaterial = new THREE.ShadowMaterial({ opacity: 0.2 });
    const plane = new THREE.Mesh(planeGeometry, planeMaterial);
    plane.rotation.x = -Math.PI / 2;
    plane.position.y = -0.01;
    plane.receiveShadow = true;
    scene.add(plane);

    let lastWidth = cardRect.width;
    let lastHeight = cardRect.height;

    const resizeObserver = new ResizeObserver(() => {
      const rect = card.getBoundingClientRect();
      if (rect.width !== lastWidth || rect.height !== lastHeight) {
        lastWidth = rect.width;
        lastHeight = rect.height;
        camera.aspect = rect.width / rect.height;
        camera.updateProjectionMatrix();
        renderer.setSize(rect.width, rect.height, false);
      }
    });
    resizeObserver.observe(card);
    // ✅ HIDE SPINNER HERE
    const spinner = document.getElementById('universeSpinner');
    if (spinner) {
      spinner.classList.add('d-none');
    }
    function animate() {
      requestAnimationFrame(animate);
      if (!isVisible) return;
      if (isMouseOver) model.rotation.y += 0.01;
      controls.update();
      renderer.render(scene, camera);
    }

    animate();
  });
});
