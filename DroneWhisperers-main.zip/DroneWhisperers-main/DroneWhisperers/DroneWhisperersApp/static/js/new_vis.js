document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('waterChart')?.getContext('2d');
  
    if (!ctx) {
      console.error("The element with id 'waterChart' was not found.");
      return;
    }
  
    const data = {
      labels: [],
      datasets: [
        {
          label: 'Hourly Consumption (litres)',
          parsing: false,
          data: [],
          borderColor: 'rgba(54, 162, 235, 1)',
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          fill: true,
          tension: 0.3,
          hidden: false,
          pointRadius: 3,
          pointHoverRadius: 5
        },
        {
          label: 'Daily Consumption (litres)',
          parsing: false,
          data: [],
          borderColor: 'rgba(255, 99, 132, 1)',
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          fill: true,
          tension: 0.3,
          hidden: true,
          pointRadius: 3,
          pointHoverRadius: 5
        }
      ]
    };
  
    const waterChart = new Chart(ctx, {
      type: 'line',
      data: data,
      options: {
        responsive: true,
        animation: {
          duration: 500,
          easing: 'easeOutQuart'
        },
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'minute',
              displayFormats: { minute: 'HH:mm' }
            },
            title: { display: true, text: 'Time' },
            ticks: {
              source: 'auto',
              autoSkip: true,
              maxRotation: 0
            }
          },
          y: {
            beginAtZero: true,
            title: { display: true, text: 'Consumption (litres)' }
          }
        },
   
             
             
plugins: {
  legend: {
    onClick: (e, legendItem, legend) => {
      const chart = legend.chart;
      const idx   = legendItem.datasetIndex;
      const metas = chart.data.datasets.map((_, i) => chart.getDatasetMeta(i));

      // Are we in a state where ONLY `idx` is visible?
      const onlyClickedVisible = metas.every((m, i) =>
        i === idx 
          ? m.hidden === false 
          : m.hidden === true
      );

      if (onlyClickedVisible) {
        // clicking again -> show both
        metas.forEach(m => m.hidden = false);
        // (optional) reset your x-axis to full-day & full-hour ranges,
        // or just leave the last used view
      } else {
        // hide all except the one you clicked
        metas.forEach((m, i) => m.hidden = (i !== idx));

        // switch your axis/unit based on which you’ve now showing
        if (idx === 0) {
          setHourlyView();
        } else {
          setDailyView();
        }
      }

      chart.update();
    }
  }
}
      }
    });
  
    function initializeChart() {
      const now = new Date();
      const hourlyData = [];
      const dailyData = [];
  
      // Hourly data: minute-by-minute for current hour
      const hourlyStart = new Date(now);
      hourlyStart.setMinutes(0, 0, 0);
      for (let time = new Date(hourlyStart); time <= now; time.setMinutes(time.getMinutes() + 1)) {
        hourlyData.push({ x: new Date(time), y: Math.random() * 100 });
      }
  
      // Daily data: hour-by-hour from midnight to current hour
      const dailyStart = new Date(now);
      dailyStart.setHours(0, 0, 0, 0);
      const currentHour = now.getHours();
      for (let hour = 0; hour <= currentHour; hour++) {
        const date = new Date(dailyStart);
        date.setHours(hour);
        dailyData.push({ x: date, y: Math.random() * 2400 });
      }
  
      data.datasets[0].data = hourlyData;
      data.datasets[1].data = dailyData;
  
      setHourlyView();
    }
  
    function setHourlyView() {
      const now = new Date();
      const hourlyStart = new Date(now);
      hourlyStart.setMinutes(0, 0, 0);
  
      waterChart.options.scales.x.time.unit = 'minute';
      waterChart.options.scales.x.time.displayFormats = { minute: 'HH:mm' };
      waterChart.options.scales.x.min = hourlyStart;
      waterChart.options.scales.x.max = now;
  
      data.datasets[0].hidden = false;
      data.datasets[1].hidden = true;
      waterChart.update('active');
    }
  
    function setDailyView() {
      const now = new Date();
      const dailyStart = new Date(now);
      dailyStart.setHours(0, 0, 0, 0);
      const endOfCurrentHour = new Date(now);
      endOfCurrentHour.setMinutes(0, 0, 0);
  
      waterChart.options.scales.x.time.unit = 'hour';
      waterChart.options.scales.x.time.displayFormats = { hour: 'HH:00' };
      waterChart.options.scales.x.min = dailyStart;
      waterChart.options.scales.x.max = endOfCurrentHour;
  
      data.datasets[0].hidden = true;
      data.datasets[1].hidden = false;
      waterChart.update('active');
    }
  
    initializeChart();
  
    setInterval(() => {
      const now = new Date();
      const currentMinute = new Date(now).setSeconds(0, 0);
      const currentHour = new Date(now).setMinutes(0, 0, 0);
    
      // HOURLY update
      const lastHourly = data.datasets[0].data.at(-1);
      const lastHourlyTime = lastHourly ? new Date(lastHourly.x).setSeconds(0, 0) : null;
    
      if (lastHourlyTime !== currentMinute && currentMinute > lastHourlyTime) {
        data.datasets[0].data.push({ x: new Date(currentMinute), y: Math.random() * 100 });
        if (data.datasets[0].data.length > 60) {
          data.datasets[0].data.shift(); // maintain 60 points max
        }
    
        // Update x-axis limits
        const hourlyStart = new Date(now);
        hourlyStart.setMinutes(0, 0, 0);
        waterChart.options.scales.x.min = hourlyStart;
        waterChart.options.scales.x.max = now;
      }
    
      // DAILY update
      const lastDaily = data.datasets[1].data.at(-1);
      const lastDailyTime = lastDaily ? new Date(lastDaily.x).setMinutes(0, 0, 0) : null;
    
      if (lastDailyTime !== currentHour && currentHour > lastDailyTime) {
        data.datasets[1].data.push({ x: new Date(currentHour), y: Math.random() * 2400 });
    
        const dailyStart = new Date(now);
        dailyStart.setHours(0, 0, 0, 0);
        const endOfCurrentHour = new Date(now);
        endOfCurrentHour.setMinutes(0, 0, 0);
        waterChart.options.scales.x.min = dailyStart;
        waterChart.options.scales.x.max = endOfCurrentHour;
      }
    
      waterChart.update('active');
    }, 60 * 1000);
    
  });
  


// gas consumption>>>>>>>>>>>>>>>>>>>>>>>>>>>
document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('gasChart')?.getContext('2d');
  
    if (!ctx) {
      console.error("The element with id 'waterChart' was not found.");
      return;
    }
  
    const data = {
      labels: [],
      datasets: [
        {
          label: 'Hourly Consumption (litres)',
          parsing: false,
          data: [],
          borderColor: 'rgba(54, 162, 235, 1)',
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          fill: true,
          tension: 0.3,
          hidden: false,
          pointRadius: 3,
          pointHoverRadius: 5
        },
        {
          label: 'Daily Consumption (litres)',
          parsing: false,
          data: [],
          borderColor: 'rgba(255, 99, 132, 1)',
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          fill: true,
          tension: 0.3,
          hidden: true,
          pointRadius: 3,
          pointHoverRadius: 5
        }
      ]
    };
  
    const waterChart = new Chart(ctx, {
      type: 'line',
      data: data,
      options: {
        responsive: true,
        animation: {
          duration: 500,
          easing: 'easeOutQuart'
        },
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'minute',
              displayFormats: { minute: 'HH:mm' }
            },
            title: { display: true, text: 'Time' },
            ticks: {
              source: 'auto',
              autoSkip: true,
              maxRotation: 0
            }
          },
          y: {
            beginAtZero: true,
            title: { display: true, text: 'Consumption (litres)' }
          }
        },
        plugins: {
  legend: {
    onClick: (e, legendItem, legend) => {
      const chart = legend.chart;
      const idx   = legendItem.datasetIndex;
      const metas = chart.data.datasets.map((_, i) => chart.getDatasetMeta(i));

      // Are we in a state where ONLY `idx` is visible?
      const onlyClickedVisible = metas.every((m, i) =>
        i === idx 
          ? m.hidden === false 
          : m.hidden === true
      );

      if (onlyClickedVisible) {
        // clicking again -> show both
        metas.forEach(m => m.hidden = false);
        // (optional) reset your x-axis to full-day & full-hour ranges,
        // or just leave the last used view
      } else {
        // hide all except the one you clicked
        metas.forEach((m, i) => m.hidden = (i !== idx));

        // switch your axis/unit based on which you’ve now showing
        if (idx === 0) {
          setHourlyView();
        } else {
          setDailyView();
        }
      }

      chart.update();
    }
  }
}

      }
    });
  
    function initializeChart() {
      const now = new Date();
      const hourlyData = [];
      const dailyData = [];
  
      // Hourly data: minute-by-minute for current hour
      const hourlyStart = new Date(now);
      hourlyStart.setMinutes(0, 0, 0);
      for (let time = new Date(hourlyStart); time <= now; time.setMinutes(time.getMinutes() + 1)) {
        hourlyData.push({ x: new Date(time), y: Math.random() * 100 });
      }
  
      // Daily data: hour-by-hour from midnight to current hour
      const dailyStart = new Date(now);
      dailyStart.setHours(0, 0, 0, 0);
      const currentHour = now.getHours();
      for (let hour = 0; hour <= currentHour; hour++) {
        const date = new Date(dailyStart);
        date.setHours(hour);
        dailyData.push({ x: date, y: Math.random() * 2400 });
      }
  
      data.datasets[0].data = hourlyData;
      data.datasets[1].data = dailyData;
  
      setHourlyView();
    }
  
    function setHourlyView() {
      const now = new Date();
      const hourlyStart = new Date(now);
      hourlyStart.setMinutes(0, 0, 0);
  
      waterChart.options.scales.x.time.unit = 'minute';
      waterChart.options.scales.x.time.displayFormats = { minute: 'HH:mm' };
      waterChart.options.scales.x.min = hourlyStart;
      waterChart.options.scales.x.max = now;
  
      data.datasets[0].hidden = false;
      data.datasets[1].hidden = true;
      waterChart.update('active');
    }
  
    function setDailyView() {
      const now = new Date();
      const dailyStart = new Date(now);
      dailyStart.setHours(0, 0, 0, 0);
      const endOfCurrentHour = new Date(now);
      endOfCurrentHour.setMinutes(0, 0, 0);
  
      waterChart.options.scales.x.time.unit = 'hour';
      waterChart.options.scales.x.time.displayFormats = { hour: 'HH:00' };
      waterChart.options.scales.x.min = dailyStart;
      waterChart.options.scales.x.max = endOfCurrentHour;
  
      data.datasets[0].hidden = true;
      data.datasets[1].hidden = false;
      waterChart.update('active');
    }
  
    initializeChart();
  
    setInterval(() => {
      const now = new Date();
      const currentMinute = new Date(now).setSeconds(0, 0);
      const currentHour = new Date(now).setMinutes(0, 0, 0);
    
      // HOURLY update
      const lastHourly = data.datasets[0].data.at(-1);
      const lastHourlyTime = lastHourly ? new Date(lastHourly.x).setSeconds(0, 0) : null;
    
      if (lastHourlyTime !== currentMinute && currentMinute > lastHourlyTime) {
        data.datasets[0].data.push({ x: new Date(currentMinute), y: Math.random() * 100 });
        if (data.datasets[0].data.length > 60) {
          data.datasets[0].data.shift(); // maintain 60 points max
        }
    
        // Update x-axis limits
        const hourlyStart = new Date(now);
        hourlyStart.setMinutes(0, 0, 0);
        waterChart.options.scales.x.min = hourlyStart;
        waterChart.options.scales.x.max = now;
      }
    
      // DAILY update
      const lastDaily = data.datasets[1].data.at(-1);
      const lastDailyTime = lastDaily ? new Date(lastDaily.x).setMinutes(0, 0, 0) : null;
    
      if (lastDailyTime !== currentHour && currentHour > lastDailyTime) {
        data.datasets[1].data.push({ x: new Date(currentHour), y: Math.random() * 2400 });
    
        const dailyStart = new Date(now);
        dailyStart.setHours(0, 0, 0, 0);
        const endOfCurrentHour = new Date(now);
        endOfCurrentHour.setMinutes(0, 0, 0);
        waterChart.options.scales.x.min = dailyStart;
        waterChart.options.scales.x.max = endOfCurrentHour;
      }
    
      waterChart.update('active');
    }, 60 * 1000);
    
  });
  

// electricity
document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('electricityChart')?.getContext('2d');
  
    if (!ctx) {
      console.error("The element with id 'waterChart' was not found.");
      return;
    }
  
    const data = {
      labels: [],
      datasets: [
        {
          label: 'Hourly Consumption (Kw)',
          parsing: false,
          data: [],
          borderColor: 'rgba(54, 162, 235, 1)',
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          fill: true,
          tension: 0.3,
          hidden: false,
          pointRadius: 3,
          pointHoverRadius: 5
        },
        {
          label: 'Daily Consumption (Kw)',
          parsing: false,
          data: [],
          borderColor: 'rgba(255, 99, 132, 1)',
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          fill: true,
          tension: 0.3,
          hidden: true,
          pointRadius: 3,
          pointHoverRadius: 5
        }
      ]
    };
  
    const waterChart = new Chart(ctx, {
      type: 'line',
      data: data,
      options: {
        responsive: true,
        animation: {
          duration: 500,
          easing: 'easeOutQuart'
        },
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'minute',
              displayFormats: { minute: 'HH:mm' }
            },
            title: { display: true, text: 'Time' },
            ticks: {
              source: 'auto',
              autoSkip: true,
              maxRotation: 0
            }
          },
          y: {
            beginAtZero: true,
            title: { display: true, text: 'Consumption (Kw)' }
          }
        },
        plugins: {
  legend: {
    onClick: (e, legendItem, legend) => {
      const chart = legend.chart;
      const idx   = legendItem.datasetIndex;
      const metas = chart.data.datasets.map((_, i) => chart.getDatasetMeta(i));

      // Are we in a state where ONLY `idx` is visible?
      const onlyClickedVisible = metas.every((m, i) =>
        i === idx 
          ? m.hidden === false 
          : m.hidden === true
      );

      if (onlyClickedVisible) {
        // clicking again -> show both
        metas.forEach(m => m.hidden = false);
        // (optional) reset your x-axis to full-day & full-hour ranges,
        // or just leave the last used view
      } else {
        // hide all except the one you clicked
        metas.forEach((m, i) => m.hidden = (i !== idx));

        // switch your axis/unit based on which you’ve now showing
        if (idx === 0) {
          setHourlyView();
        } else {
          setDailyView();
        }
      }

      chart.update();
    }
  }
}

      }
    });
  
    function initializeChart() {
      const now = new Date();
      const hourlyData = [];
      const dailyData = [];
  
      // Hourly data: minute-by-minute for current hour
      const hourlyStart = new Date(now);
      hourlyStart.setMinutes(0, 0, 0);
      for (let time = new Date(hourlyStart); time <= now; time.setMinutes(time.getMinutes() + 1)) {
        hourlyData.push({ x: new Date(time), y: Math.random() * 100 });
      }
  
      // Daily data: hour-by-hour from midnight to current hour
      const dailyStart = new Date(now);
      dailyStart.setHours(0, 0, 0, 0);
      const currentHour = now.getHours();
      for (let hour = 0; hour <= currentHour; hour++) {
        const date = new Date(dailyStart);
        date.setHours(hour);
        dailyData.push({ x: date, y: Math.random() * 2400 });
      }
  
      data.datasets[0].data = hourlyData;
      data.datasets[1].data = dailyData;
  
      setHourlyView();
    }
  
    function setHourlyView() {
      const now = new Date();
      const hourlyStart = new Date(now);
      hourlyStart.setMinutes(0, 0, 0);
  
      waterChart.options.scales.x.time.unit = 'minute';
      waterChart.options.scales.x.time.displayFormats = { minute: 'HH:mm' };
      waterChart.options.scales.x.min = hourlyStart;
      waterChart.options.scales.x.max = now;
  
      data.datasets[0].hidden = false;
      data.datasets[1].hidden = true;
      waterChart.update('active');
    }
  
    function setDailyView() {
      const now = new Date();
      const dailyStart = new Date(now);
      dailyStart.setHours(0, 0, 0, 0);
      const endOfCurrentHour = new Date(now);
      endOfCurrentHour.setMinutes(0, 0, 0);
  
      waterChart.options.scales.x.time.unit = 'hour';
      waterChart.options.scales.x.time.displayFormats = { hour: 'HH:00' };
      waterChart.options.scales.x.min = dailyStart;
      waterChart.options.scales.x.max = endOfCurrentHour;
  
      data.datasets[0].hidden = true;
      data.datasets[1].hidden = false;
      waterChart.update('active');
    }
  
    initializeChart();
  
    setInterval(() => {
      const now = new Date();
      const currentMinute = new Date(now).setSeconds(0, 0);
      const currentHour = new Date(now).setMinutes(0, 0, 0);
    
      // HOURLY update
      const lastHourly = data.datasets[0].data.at(-1);
      const lastHourlyTime = lastHourly ? new Date(lastHourly.x).setSeconds(0, 0) : null;
    
      if (lastHourlyTime !== currentMinute && currentMinute > lastHourlyTime) {
        data.datasets[0].data.push({ x: new Date(currentMinute), y: Math.random() * 100 });
        if (data.datasets[0].data.length > 60) {
          data.datasets[0].data.shift(); // maintain 60 points max
        }
    
        // Update x-axis limits
        const hourlyStart = new Date(now);
        hourlyStart.setMinutes(0, 0, 0);
        waterChart.options.scales.x.min = hourlyStart;
        waterChart.options.scales.x.max = now;
      }
    
      // DAILY update
      const lastDaily = data.datasets[1].data.at(-1);
      const lastDailyTime = lastDaily ? new Date(lastDaily.x).setMinutes(0, 0, 0) : null;
    
      if (lastDailyTime !== currentHour && currentHour > lastDailyTime) {
        data.datasets[1].data.push({ x: new Date(currentHour), y: Math.random() * 2400 });
    
        const dailyStart = new Date(now);
        dailyStart.setHours(0, 0, 0, 0);
        const endOfCurrentHour = new Date(now);
        endOfCurrentHour.setMinutes(0, 0, 0);
        waterChart.options.scales.x.min = dailyStart;
        waterChart.options.scales.x.max = endOfCurrentHour;
      }
    
      waterChart.update('active');
    }, 60 * 1000);
    
  });
