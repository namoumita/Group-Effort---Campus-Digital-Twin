import * as THREE from '/static/three/build/three.module.js';
import { GLTFLoader } from '/static/three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from '/static/three/examples/jsm/controls/OrbitControls.js';
const scenes = [];
let isAnimating = false;
let animationFrameId = null;

// Observer to update visibility status for each canvas
const visibilityObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    const canvas = entry.target;
    // Find the scene object associated with this canvas
    const sceneObj = scenes.find(s => s.canvas === canvas);
    if (sceneObj) {
      sceneObj.isVisible = entry.isIntersecting;
    }
    // If any canvas becomes visible and we're not animating, restart the loop
    if (entry.isIntersecting && !isAnimating) {
      animate();
    }
  });
}, { threshold: 0.1 });

// Create a 3D model and add its related objects to the central scenes array
function create3DModel(canvasId, modelPath) {
  const canvas = document.getElementById(canvasId);
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setSize(400, 400);
  renderer.setClearColor(0xf8f9fa);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000);
  camera.position.set(0, 2, 5);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.autoRotate = false;
  controls.enableZoom = false;
  let isMouseOver = false;

  canvas.addEventListener('mouseenter', () => {
    isMouseOver = true;
    controls.autoRotate = true;
  });
  canvas.addEventListener('mouseleave', () => {
    isMouseOver = false;
    controls.autoRotate = false;
  });

  // Add lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 1);
  scene.add(ambientLight);
  const spotLight = new THREE.SpotLight(0xffffff, 1);
  spotLight.position.set(10, 10, 10);
  spotLight.castShadow = true;
  scene.add(spotLight);

  // Load the model
  const loader = new GLTFLoader();
  loader.load(
    modelPath,
    (gltf) => {
      const model = gltf.scene;
      model.traverse((child) => {
        if (child.isMesh) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });
      model.scale.set(0.6, 0.6, 0.6);
      scene.add(model);

      // Save all relevant data for the centralized loop.
      scenes.push({
        renderer,
        scene,
        camera,
        controls,
        model,
        isMouseOverRef: () => isMouseOver,
        canvas,
        isVisible: false // Initially false until set by observer.
      });
      // Start observing the canvas for visibility
      visibilityObserver.observe(canvas);
    },
    undefined,
    (error) => { console.error('Error loading model:', error); }
  );
}

// Global animation loop that only runs if at least one scene is visible.
function animate() {
  // Check if any scene is visible
  if (!scenes.some(s => s.isVisible)) {
    isAnimating = false;
    return; // Stop updating if nothing is visible.
  }
  
  isAnimating = true;
  animationFrameId = requestAnimationFrame(animate);
  
  scenes.forEach(({ renderer, scene, camera, controls, model, isMouseOverRef }) => {
    // Only update rotation when the mouse is over the canvas
    if (isMouseOverRef()) {
      model.rotation.y += 0.01;
    }
    controls.update();
    renderer.render(scene, camera);
  });
}

// Initial Intersection Observer to trigger model creation
const loadObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      create3DModel(entry.target.id, entry.target.dataset.model);
      loadObserver.unobserve(entry.target); // Only load once per canvas.
    }
  });
}, { threshold: 0.1 });

// Start observing canvases for model loading.
document.querySelectorAll('.model-container').forEach((element) => {
  loadObserver.observe(element);
});
