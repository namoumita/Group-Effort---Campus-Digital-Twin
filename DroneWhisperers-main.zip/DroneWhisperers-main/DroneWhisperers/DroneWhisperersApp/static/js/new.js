async function createLineChart({ url, canvasId, label, borderColor, backgroundColor, yLabel, title }) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
    
    const data = await response.json();

    const ctx = document.getElementById(canvasId).getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        datasets: [{
          label,
          data,
          borderColor,
          backgroundColor,
          fill: true,
          tension: 0.3
        }]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'day',
              tooltipFormat: 'MMM dd, yyyy',
              displayFormats: {
                day: 'MMM dd, yy'
              }
            },
            title: {
              display: true,
              text: 'Date'
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: yLabel
            }
          }
        },
        plugins: {
          title: {
            display: true,
            text: title
          }
        }
      }
    });

    const spinner = document.getElementById(`${canvasId.replace('Chart', '')}Spinner`);
    if (spinner) spinner.classList.add('d-none');
    document.getElementById(canvasId).classList.remove('d-none');

  } catch (err) {
    console.error(`Error loading data from ${url}:`, err);
  }

  window.addEventListener('resize', () => {
    const canvas = document.getElementById(canvasId);
    const parent = canvas.parentElement;
    canvas.height = parent.offsetHeight * 0.5;
  });
}

// Initialize all charts
(async () => {
  await createLineChart({
    url: '/water-consumption',
    canvasId: 'waterChart',
    label: 'Water Consumption (litres)',
    borderColor: 'rgba(54, 162, 235, 1)',
    backgroundColor: 'rgba(54, 162, 235, 0.2)',
    yLabel: 'Consumption (litres)',
    title: 'Daily Water Consumption Over Time'
  });

  await createLineChart({
    url: '/gas-consumption',
    canvasId: 'gasChart',
    label: 'Gas Consumption (litres)',
    borderColor: 'rgba(255, 99, 132, 1)',
    backgroundColor: 'rgba(255, 99, 132, 0.2)',
    yLabel: 'Consumption (litres)',
    title: 'Daily Gas Consumption Over Time'
  });

  await createLineChart({
    url: '/electricity-consumption',
    canvasId: 'electricityChart',
    label: 'Electricity Consumption (Kw)',
    borderColor: 'rgba(75, 192, 192, 1)',
    backgroundColor: 'rgba(75, 192, 192, 0.2)',
    yLabel: 'Consumption (Kw)',
    title: 'Daily Electricity Consumption Over Time'
  });
})();
