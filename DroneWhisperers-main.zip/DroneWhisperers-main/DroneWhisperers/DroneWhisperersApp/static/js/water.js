fetch('/water-consumption')
  .then(response => response.json())
  .then(data => {
    const ctx = document.getElementById('waterChart').getContext('2d');

    new Chart(ctx, {
      type: 'line',
      data: {
        datasets: [{
          label: 'Water Consumption (litres)',
          data: data,
          borderColor: 'rgba(54, 162, 235, 1)',
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          fill: true,
          tension: 0.3
        }]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'day',
              tooltipFormat: 'MMM dd, yyyy',
              displayFormats: {
                day: 'MMM dd, yy'  // This formats the x-axis label to show month, day, and year
              }
            },
            title: {
              display: true,
              text: 'Date'
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Consumption (litres)'
            }
          }
        },
        plugins: {
          title: {
            display: true,
            text: 'Daily Water Consumption Over Time'
          }
        }
      }
    });
  })
  .catch(err => console.error("Error loading data:", err));
// Resize canvas dynamically on window resize
window.addEventListener('resize', function () {
    let canvas = document.getElementById('waterChart');
    let parent = canvas.parentElement;
    let parentHeight = parent.offsetHeight;
    
    // Set the canvas height to be 50% of the parent container height
    canvas.height = parentHeight * 0.5; 
  });
fetch('/gas-consumption')
  .then(response => response.json())
  .then(data => {
    const ctx = document.getElementById('gasChart').getContext('2d');

    new Chart(ctx, {
      type: 'line',
      data: {
        datasets: [{
          label: 'Gas Consumption (litres)',
          data: data,
          borderColor: 'rgba(54, 162, 235, 1)',
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          fill: true,
          tension: 0.3
        }]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'day',
              tooltipFormat: 'MMM dd, yyyy',
              displayFormats: {
                day: 'MMM dd, yy'  // This formats the x-axis label to show month, day, and year
              }
            },
            title: {
              display: true,
              text: 'Date'
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Consumption (litres)'
            }
          }
        },
        plugins: {
          title: {
            display: true,
            text: 'Daily Gas Consumption Over Time'
          }
        }
      }
    });
  })
  .catch(err => console.error("Error loading data:", err));
// Resize canvas dynamically on window resize
window.addEventListener('resize', function () {
    let canvas = document.getElementById('gasChart');
    let parent = canvas.parentElement;
    let parentHeight = parent.offsetHeight;
    
    // Set the canvas height to be 50% of the parent container height
    canvas.height = parentHeight * 0.5; 
  });
  
fetch('/electricity-consumption')
  .then(response => response.json())
  .then(data => {
    const ctx = document.getElementById('electricityChart').getContext('2d');

    new Chart(ctx, {
      type: 'line',
      data: {
        datasets: [{
          label: 'Electricity Consumption (Kw)',
          data: data,
          borderColor: 'rgba(54, 163, 235, 0.41)',
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          fill: true,
          tension: 0.3
        }]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'day',
              tooltipFormat: 'MMM dd, yyyy',
              displayFormats: {
                day: 'MMM dd, yy'  // This formats the x-axis label to show month, day, and year
              }
            },
            title: {
              display: true,
              text: 'Date'
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Consumption (litres)'
            }
          }
        },
        plugins: {
          title: {
            display: true,
            text: 'Daily Electricity Consumption Over Time'
          }
        }
      }
    });
       // Show canvas and hide spinner after chart is ready
       document.getElementById('electricityChart').classList.remove('d-none');
       document.getElementById('electricitySpinner').classList.add('d-none');
  })
  .catch(err => console.error("Error loading data:", err));
// Resize canvas dynamically on window resize
window.addEventListener('resize', function () {
    let canvas = document.getElementById('electricityChart');
    let parent = canvas.parentElement;
    let parentHeight = parent.offsetHeight;
    
    // Set the canvas height to be 50% of the parent container height
    canvas.height = parentHeight * 0.5; 
  });
  
