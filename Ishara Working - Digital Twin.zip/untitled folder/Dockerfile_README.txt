### README for Dockerfile

```
FROM confluentinc/cp-kafka-connect:7.9.0

RUN confluent-hub install --no-prompt questdb/kafka-questdb-connector:0.12
```