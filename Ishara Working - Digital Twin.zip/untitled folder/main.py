import json
import polars as pl
from confluent_kafka import Producer

df = pl.read_csv(
    source = '/Users/sayurugunawardana/untitled folder/Data/water_consumption_15min.csv',
    has_header=True,
)


p = Producer({"bootstrap.servers": "localhost:9092"})


def delivery_report(err, msg):
    """ Called once for each message produced to indicate delivery result.
        Triggered by poll() or flush(). """
    if err is not None:
        print('Message delivery failed: {}'.format(err))
    else:
        print('Message delivered to {} [{}]'.format(msg.topic(), msg.partition()))


for row in df.iter_rows(named=True):
    print(row)


    p.poll(0)
    p.produce(
        'water_queue',
        json.dumps(row).encode('utf-8'),
        callback=delivery_report
    )


p.flush()